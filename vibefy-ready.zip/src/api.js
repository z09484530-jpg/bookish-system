import axios from 'axios';

const API_KEY = 'b628d35452msh77090e225e8245ap12eeb5jsne5a71a4a3fab';
const API_HOST = 'spotify23.p.rapidapi.com';

const api = axios.create({
  baseURL: 'https://spotify23.p.rapidapi.com',
  headers: {
    'x-rapidapi-host': API_HOST,
    'x-rapidapi-key': API_KEY
  },
  timeout: 15000
});

/** Human-readable error from RapidAPI / network */
export function getApiErrorMessage(error) {
  const status = error?.response?.status;
  const data = error?.response?.data;

  if (error?.code === 'ECONNABORTED' || error?.message?.includes('timeout')) {
    return 'Превышено время ожидания. Попробуй ещё раз.';
  }
  if (!error?.response) {
    return 'Нет соединения с API. Проверь интернет.';
  }
  if (status === 401 || status === 403) {
    return 'API ключ недействителен или доступ запрещён. Проверь RapidAPI ключ.';
  }
  if (status === 429) {
    return 'Слишком много запросов (rate limit). Подожди 1–2 минуты.';
  }
  if (status === 404) {
    return 'Эндпоинт не найден.';
  }
  if (status >= 500) {
    return 'Сервер Spotify/RapidAPI временно недоступен.';
  }

  const msg =
    data?.message ||
    data?.error?.message ||
    data?.error ||
    (typeof data === 'string' ? data : null);

  return msg || `Ошибка API (${status || 'unknown'})`;
}

/** Normalize RapidAPI Spotify23 track item */
export function normalizeTrack(item) {
  if (!item) return null;
  const d = item.data || item;

  const id =
    d.id ||
    (d.uri ? String(d.uri).split(':').pop() : null) ||
    item.id;

  if (!id) return null;

  const artistsRaw = d.artists?.items || d.artists || [];
  const artists = (Array.isArray(artistsRaw) ? artistsRaw : []).map((a) => ({
    name: a?.profile?.name || a?.name || 'Unknown',
    uri: a?.uri || null
  }));

  const coverSources =
    d.albumOfTrack?.coverArt?.sources ||
    d.album?.images ||
    d.album?.coverArt?.sources ||
    [];

  const images = (Array.isArray(coverSources) ? coverSources : [])
    .map((s) => ({
      url: typeof s === 'string' ? s : s?.url || '',
      width: s?.width || 300,
      height: s?.height || 300
    }))
    .filter((s) => s.url);

  const image =
    images.find((i) => i.width === 300)?.url ||
    images.find((i) => i.width >= 300)?.url ||
    images[0]?.url ||
    'https://via.placeholder.com/300';

  const duration_ms =
    d.duration?.totalMilliseconds ||
    d.duration_ms ||
    (typeof d.duration === 'number' ? d.duration : 0) ||
    0;

  const albumName = d.albumOfTrack?.name || d.album?.name || '';

  // Official preview often needs real hash — embed is the reliable fallback
  const preview_url =
    d.preview_url ||
    d.audioPreview?.url ||
    null;

  return {
    id,
    uri: d.uri || `spotify:track:${id}`,
    name: d.name || 'Unknown Track',
    artists,
    artist: artists.map((a) => a.name).join(', ') || 'Unknown Artist',
    album: { name: albumName, images },
    image,
    duration_ms,
    contentRating: d.contentRating?.label || 'NONE',
    playability: d.playability?.playable ?? true,
    preview_url,
    hasPreview: Boolean(preview_url)
  };
}

export function extractTrackItems(data) {
  if (!data) return [];
  if (Array.isArray(data?.tracks?.items)) return data.tracks.items;
  if (Array.isArray(data?.tracks)) return data.tracks;
  if (Array.isArray(data?.items)) return data.items;
  if (Array.isArray(data)) return data;
  return [];
}

export const searchTracks = async (q, offset = 0) => {
  try {
    const { data } = await api.get('/search/', {
      params: {
        q,
        type: 'tracks',
        offset,
        limit: 20,
        numberOfTopResults: 5
      }
    });

    // RapidAPI sometimes wraps errors in 200 body
    if (data?.error || data?.status === 'error') {
      const msg =
        data?.error?.message ||
        data?.message ||
        'Search failed';
      const err = new Error(msg);
      err.response = { status: data?.error?.status || 400, data };
      throw err;
    }

    return data;
  } catch (error) {
    console.error('Search error:', error?.response?.data || error.message);
    throw error;
  }
};

export const getRecommendations = async (seedTracks) => {
  try {
    const { data } = await api.get('/recommendations/', {
      params: { limit: 20, seed_tracks: seedTracks }
    });
    if (data?.error || data?.status === 'error') {
      const msg = data?.error?.message || data?.message || 'Recommendations failed';
      const err = new Error(msg);
      err.response = { status: data?.error?.status || 400, data };
      throw err;
    }
    return data;
  } catch (error) {
    console.error('Recommendations error:', error?.response?.data || error.message);
    throw error;
  }
};

export default api;
