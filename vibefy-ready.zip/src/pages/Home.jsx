import React from 'react';
import { Link } from 'react-router-dom';

const playlists = [
  {
    id: 1,
    name: 'Хиты 2024',
    description: 'Топ треки этого года',
    image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400',
    gradient: 'linear-gradient(135deg, rgb(102, 126, 234) 0%, rgb(118, 75, 162) 100%)'
  },
  {
    id: 2,
    name: 'Чиллаут',
    description: 'Расслабляющая музыка',
    image: 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=400',
    gradient: 'linear-gradient(135deg, rgb(240, 147, 251) 0%, rgb(245, 87, 108) 100%)'
  },
  {
    id: 3,
    name: 'Тренировка',
    description: 'Энергия для спорта',
    image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=400',
    gradient: 'linear-gradient(135deg, rgb(79, 172, 254) 0%, rgb(0, 242, 254) 100%)'
  },
  {
    id: 4,
    name: 'Фокус',
    description: 'Музыка для концентрации',
    image: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400',
    gradient: 'linear-gradient(135deg, rgb(67, 233, 123) 0%, rgb(56, 249, 215) 100%)'
  }
];

const features = [
  { icon: '⌕', title: 'Умный поиск', desc: 'Находи любимые треки за секунды' },
  { icon: '♥', title: 'Избранное', desc: 'Сохраняй любимые песни' },
  { icon: '✦', title: 'Рекомендации', desc: 'Открывай новую музыку на основе вкусов' },
  { icon: '🎵', title: 'Высокое качество', desc: 'Наслаждайся чистым звуком' }
];

const quickActions = [
  { icon: '⌕', text: 'Найти музыку', link: '/search' },
  { icon: '♥', text: 'Избранное', link: '/favorites' },
  { icon: '✦', text: 'Рекомендации', link: '/recommendations' }
];

export default function Home() {
  return (
    <div className="home-page">
      <div className="hero-section">
        <h1>
          Добро пожаловать в <span className="brand-gradient">VIBEFY</span>
        </h1>
        <p className="hero-subtitle">Открывай новую музыку каждый день</p>
        <div className="quick-actions">
          {quickActions.map((action, i) => (
            <Link
              key={action.link}
              to={action.link}
              className="quick-action-card"
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              <span className="action-icon">{action.icon}</span>
              <span className="action-text">{action.text}</span>
            </Link>
          ))}
        </div>
      </div>

      <section className="playlists-section">
        <h2>Популярные плейлисты</h2>
        <div className="playlists-grid">
          {playlists.map((pl, i) => (
            <div
              key={pl.id}
              className="playlist-card"
              style={{
                animationDelay: `${i * 0.1}s`,
                background: pl.gradient
              }}
            >
              <div className="playlist-image-wrapper">
                <img src={pl.image} alt={pl.name} className="playlist-image" />
              </div>
              <div className="playlist-info">
                <h3 className="playlist-name">{pl.name}</h3>
                <p className="playlist-description">{pl.description}</p>
              </div>
              <button className="playlist-play-btn">▶</button>
            </div>
          ))}
        </div>
      </section>

      <section className="features-section">
        <h2>Возможности</h2>
        <div className="features-grid">
          {features.map((f) => (
            <div key={f.title} className="feature-card">
              <div className="feature-icon">{f.icon}</div>
              <h3>{f.title}</h3>
              <p>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
