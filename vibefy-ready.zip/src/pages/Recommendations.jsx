import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useFavorites } from '../context/FavoritesContext';
import { getRecommendations, normalizeTrack, getApiErrorMessage, extractTrackItems } from '../api';
import TrackCard from '../components/TrackCard';

export default function Recommendations({ onPlay }) {
  const { favorites } = useFavorites();
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const loadRecommendations = useCallback(async () => {
    if (favorites.length === 0) return;
    setLoading(true);
    setError(null);
    try {
      const seeds = favorites
        .slice(0, 5)
        .map((t) => t.id)
        .filter(Boolean)
        .join(',');
      if (!seeds) {
        setTracks([]);
        return;
      }
      const data = await getRecommendations(seeds);
      const items = extractTrackItems(data);
      setTracks(items.map(normalizeTrack).filter(Boolean));
    } catch (err) {
      setError(getApiErrorMessage(err));
      setTracks([]);
    } finally {
      setLoading(false);
    }
  }, [favorites]);

  useEffect(() => {
    loadRecommendations();
  }, [loadRecommendations]);

  return (
    <div className="recommendations-page">
      <div className="page-header recommendations-header">
        <div className="page-header-icon">✦</div>
        <div>
          <h1>Рекомендации</h1>
          <p className="page-subtitle">Персональные рекомендации на основе твоих вкусов</p>
        </div>
      </div>

      {favorites.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🎵</div>
          <h2>Добавь треки в избранное</h2>
          <p className="empty-hint">
            Чтобы получить персональные рекомендации, добавь несколько любимых треков в избранное
          </p>
          <Link to="/search" className="cta-btn">
            НАЙТИ МУЗЫКУ
          </Link>
        </div>
      ) : loading ? (
        <div className="loading-state">
          <div className="spinner" />
          <p>Подбираем рекомендации...</p>
        </div>
      ) : error ? (
        <div className="error-state">
          <p>{error}</p>
          <button className="cta-btn" onClick={loadRecommendations}>
            Попробовать снова
          </button>
        </div>
      ) : tracks.length === 0 ? (
        <div className="empty-state">
          <p>Рекомендации пока недоступны</p>
        </div>
      ) : (
        <div className="track-grid">
          {tracks.map((track) => (
            <TrackCard key={track.id} track={track} onPlay={onPlay} />
          ))}
        </div>
      )}
    </div>
  );
}
