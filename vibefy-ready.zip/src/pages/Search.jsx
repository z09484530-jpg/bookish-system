import React, { useState, useCallback } from 'react';
import { searchTracks, normalizeTrack, getApiErrorMessage, extractTrackItems } from '../api';
import TrackCard from '../components/TrackCard';

const SUGGESTIONS = [
  'The Weeknd',
  'Drake',
  'Taylor Swift',
  'Billie Eilish',
  'Bad Bunny',
  'Ed Sheeran'
];

export default function Search({ onPlay }) {
  const [query, setQuery] = useState('');
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [searched, setSearched] = useState(false);

  const doSearch = useCallback(async (q) => {
    if (!q.trim()) return;
    setLoading(true);
    setError(null);
    setSearched(true);
    try {
      const data = await searchTracks(q.trim());
      const items = extractTrackItems(data);
      const normalized = items.map(normalizeTrack).filter(Boolean);
      setTracks(normalized);
    } catch (err) {
      console.error(err);
      setError(getApiErrorMessage(err));
      setTracks([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    doSearch(query);
  };

  const handleSuggestion = (s) => {
    setQuery(s);
    doSearch(s);
  };

  return (
    <div className="search-page">
      <div className="search-hero">
        <h1>
          Найди <span className="brand-gradient">свой трек</span>
        </h1>
        <p className="search-subtitle">Ищи среди миллионов песен</p>

        <form className="search-form" onSubmit={handleSubmit}>
          <input
            type="text"
            className="search-input"
            placeholder="Название песни, исполнитель..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <button type="submit" className="search-btn" aria-label="Search">
            ⌕
          </button>
        </form>

        {!searched && (
          <div className="search-suggestions">
            <h3>Попробуй искать:</h3>
            <div className="suggestions-grid">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  className="suggestion-chip"
                  onClick={() => handleSuggestion(s)}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {loading && (
        <div className="loading-state">
          <div className="spinner" />
          <p>Ищем музыку...</p>
        </div>
      )}

      {error && (
        <div className="error-state">
          <p>{error}</p>
        </div>
      )}

      {!loading && searched && tracks.length === 0 && !error && (
        <div className="empty-state">
          <p>Ничего не найдено</p>
          <p className="empty-hint">Попробуй другой запрос</p>
        </div>
      )}

      {!loading && tracks.length > 0 && (
        <div className="search-results">
          <h2 className="results-count">НАЙДЕНО ТРЕКОВ: {tracks.length}</h2>
          <div className="track-grid">
            {tracks.map((track) => (
              <TrackCard key={track.id} track={track} onPlay={onPlay} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
