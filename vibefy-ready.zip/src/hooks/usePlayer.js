import { useState, useCallback } from 'react';

/**
 * Always uses Spotify Embed — music plays when you press ▶
 * (no broken CDN preview, works for almost all public tracks)
 */
export function usePlayer() {
  const [currentTrack, setCurrentTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const play = useCallback((track) => {
    if (!track?.id) return;
    setCurrentTrack(track);
    setIsPlaying(true);
  }, []);

  const toggle = useCallback(() => {
    setIsPlaying((p) => !p);
  }, []);

  const close = useCallback(() => {
    setCurrentTrack(null);
    setIsPlaying(false);
  }, []);

  return {
    currentTrack,
    isPlaying,
    useEmbed: true,
    progress: 0,
    duration: 0,
    play,
    toggle,
    seek: () => {},
    close
  };
}
