import React from 'react';

export default function Player({ track, onClose }) {
  if (!track?.id) return null;

  const image =
    track.image ||
    track.album?.images?.[0]?.url ||
    'https://via.placeholder.com/60';

  const artist =
    track.artists?.map((a) => a.name).join(', ') ||
    track.artist ||
    'Unknown Artist';

  return (
    <div className="player">
      <div className="player-track-info">
        <img src={image} alt={track.name} className="player-image" />
        <div className="player-details">
          <div className="player-track-name">{track.name}</div>
          <div className="player-artist-name">{artist}</div>
        </div>
      </div>

      <div className="player-center">
        <div className="player-embed-wrap">
          <iframe
            title="spotify-player"
            src={`https://open.spotify.com/embed/track/${track.id}?utm_source=generator&theme=0`}
            width="100%"
            height="80"
            frameBorder="0"
            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
            loading="eager"
            style={{ borderRadius: 8, minWidth: 280, border: 'none' }}
          />
        </div>
      </div>

      <div className="player-right">
        <button className="player-btn close" onClick={onClose} aria-label="Close">
          ✕
        </button>
      </div>
    </div>
  );
}
