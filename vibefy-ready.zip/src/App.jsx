import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import Home from './pages/Home';
import Search from './pages/Search';
import Favorites from './pages/Favorites';
import Recommendations from './pages/Recommendations';
import Player from './components/Player';
import { usePlayer } from './hooks/usePlayer';

export default function App() {
  const player = usePlayer();

  return (
    <div className="app">
      <Navigation />
      <div className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/search" element={<Search onPlay={player.play} />} />
          <Route path="/favorites" element={<Favorites onPlay={player.play} />} />
          <Route path="/recommendations" element={<Recommendations onPlay={player.play} />} />
        </Routes>
      </div>
      {player.currentTrack && (
        <Player track={player.currentTrack} onClose={player.close} />
      )}
    </div>
  );
}
